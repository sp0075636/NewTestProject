package Faq;

import javax.servlet.http.*;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.beans.SuperBean;
import com.conn.GetConnection;

import SQL.Sqls;

public class FAQ extends javax.servlet.http.HttpServlet {
		public void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException
{
		SuperBean beans = new SuperBean();
		ResultSet rs = null;
		RequestDispatcher rd = null;
		ArrayList dataList = new ArrayList();
		//HashMap map = new Map();
		GetConnection gc=new GetConnection();
		Connection conn = null;
		try {
			conn = gc.getConnection(33);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String param = req.getParameter("name");
		if("Provide".equalsIgnoreCase(param)){
			System.out.println("In Provide Loop");
			try {
				PreparedStatement pstmt = conn.prepareStatement(Sqls.GET_DESCRIPTION);
				pstmt.setString(1, param);
				 rs = pstmt.executeQuery();
				while(rs.next()){
					ArrayList interList = new ArrayList();
					interList.add(rs.getString(1));
					interList.add(rs.getString(2));
					interList.add(rs.getString(3));
					dataList.add(interList);
					
				}
				rd=req.getRequestDispatcher("ViewFAQ.jsp");
				System.out.println("dataList" +dataList);
				req.setAttribute("sdwList", dataList);
				rd.forward(req, res);
				
			}catch(Exception se){
				
			}

			
		}
		
	}

}
