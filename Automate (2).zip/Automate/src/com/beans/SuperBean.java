package com.beans;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;

public class SuperBean {
	public static int ein;
	public static String env;
	public static String orderid;
	static int i;
	public static Connection connection;
	
	//External ID info
	ArrayList<String> externalIdColumnNames = new ArrayList<String>();
	ArrayList<ArrayList> externalIds=new ArrayList<ArrayList>();
	int externalIdCount;

	// subproject info
	ArrayList<String> subprojectColumnNames = new ArrayList<String>();
	ArrayList<String> subprojectObjid = new ArrayList<String>();
	ArrayList<String> subrojectName = new ArrayList<String>();
	ArrayList<String> subprojectStartDate = new ArrayList<String>();
	String tempSubproject;

	// task info
	ArrayList<String> taskColumnNames = new ArrayList<String>();
	HashMap<String, ArrayList> subprojectTotasks = new HashMap<String, ArrayList>();	//To view tasks
	HashMap<String, ArrayList> subprojectTotaskUniqueids= new HashMap<String, ArrayList>();	//To get XMLs
	HashMap<String, ArrayList<HashMap<String, String>>> subprojectTotaskInfo=new HashMap<String, ArrayList<HashMap<String, String>>>();	//To Update Tasks
	
	// request,group,function info
	ArrayList<String> requestInstanceColumnNames = new ArrayList<String>();
	HashMap<String, ArrayList> subprojectTorequest = new HashMap<String, ArrayList>();	//To view Request Instances
	HashMap<String, ArrayList<HashMap<String, String>>> subprojectTorequestInfo = new HashMap<String, ArrayList<HashMap<String, String>>>();	//To Update Request Instances
	
	//updated details
	ArrayList<String> updatedRecords=new ArrayList<String>();
	
	//OrderDetails
	public static String contractObjID;
	public static String orderStatus;
	public static String orderType;
	public static String orderTitle;
	public static String orderDate;
	public static ArrayList<String> provideForModify=new ArrayList<String>();
	public static String externalSystem;
	public static String externalID;
	public static HashMap<String, String> service= new HashMap<String, String>();
	
	//Attribute details
	HashMap<String,String> objidToAttribute=new HashMap<String,String>();
	
	//Element Details
	ArrayList<ArrayList<String>> technicals=new ArrayList<ArrayList<String>>();	
	ArrayList<String> technicalColumnNames = new ArrayList<String>();
	ArrayList<ArrayList<String>> commercials=new ArrayList<ArrayList<String>>();	
	ArrayList<String> commercialColumnNames = new ArrayList<String>();
	HashMap<ArrayList,ArrayList> commTechRelation=new HashMap<ArrayList,ArrayList>(); //<(comm,tech),(service,role)>
	ArrayList<String> commtechColumnNames = new ArrayList<String>();

	//MRS,MLP xml
	String xmlType;
	HashMap<String,HashMap<String,String>> subprojectToXMLTask=new HashMap<String,HashMap<String,String>>();
	
	public HashMap<ArrayList, ArrayList> getCommTechRelation() {
		return commTechRelation;
	}

	public void setCommTechRelation(HashMap<ArrayList, ArrayList> commTechRelation) {
		this.commTechRelation = commTechRelation;
	}

	public ArrayList<String> getCommtechColumnNames() {
		return commtechColumnNames;
	}

	public void setCommtechColumnNames(ArrayList<String> commtechColumnNames) {
		this.commtechColumnNames = commtechColumnNames;
	}

	public ArrayList<String> getTechnicalColumnNames() {
		return technicalColumnNames;
	}

	public void setTechnicalColumnNames(ArrayList<String> technicalColumnNames) {
		this.technicalColumnNames = technicalColumnNames;
	}

	public ArrayList<ArrayList<String>> getTechnicals() {
		return technicals;
	}

	public void setTechnicals(ArrayList<ArrayList<String>> technicals) {
		this.technicals = technicals;
	}

	public HashMap<String, String> getObjidToAttribute() {
		return objidToAttribute;
	}

	public void setObjidToAttribute(HashMap<String, String> objidToAttribute) {
		this.objidToAttribute = objidToAttribute;
	}	

	

	public static String getEnv() {
		return env;
	}

	public static void setEnv(String env) {
		SuperBean.env = env;
	}

	public String getOrderid() {
		return orderid;
	}

	public void setOrderid(String orderid) {
		this.orderid = orderid;
	}

	public static int getI() {
		return i;
	}

	public static void setI(int i) {
		SuperBean.i = i;
	}

	public static Connection getConnection() {
		return connection;
	}

	public static void setConnection(Connection connection) {
		SuperBean.connection = connection;
	}

	public ArrayList<String> getSubprojectObjid() {
		return subprojectObjid;
	}

	public void setSubprojectObjid(ArrayList<String> subprojectObjid) {
		this.subprojectObjid = subprojectObjid;
	}

	public ArrayList<String> getSubrojectName() {
		return subrojectName;
	}

	public void setSubrojectName(ArrayList<String> subrojectName) {
		this.subrojectName = subrojectName;
	}

	public ArrayList<String> getSubprojectStartDate() {
		return subprojectStartDate;
	}

	public void setSubprojectStartDate(ArrayList<String> subprojectStartDate) {
		this.subprojectStartDate = subprojectStartDate;
	}

	

	public ArrayList<String> getSubprojectColumnNames() {
		return subprojectColumnNames;
	}

	public void setSubprojectColumnNames(ArrayList<String> subprojectColumnNames) {
		this.subprojectColumnNames = subprojectColumnNames;
	}

	public ArrayList<String> getTaskColumnNames() {
		return taskColumnNames;
	}

	public void setTaskColumnNames(ArrayList<String> taskColumnNames) {
		this.taskColumnNames = taskColumnNames;
	}

	public ArrayList<String> getRequestInstanceColumnNames() {
		return requestInstanceColumnNames;
	}

	public void setRequestInstanceColumnNames(
			ArrayList<String> requestInstanceColumnNames) {
		this.requestInstanceColumnNames = requestInstanceColumnNames;
	}

	

	public HashMap<String, ArrayList> getSubprojectTotasks() {
		return subprojectTotasks;
	}

	public void setSubprojectTotasks(
			HashMap<String, ArrayList> subprojectTotasks) {
		this.subprojectTotasks = subprojectTotasks;
	}

	public HashMap<String, ArrayList> getSubprojectTorequest() {
		return subprojectTorequest;
	}

	public void setSubprojectTorequest(
			HashMap<String, ArrayList> subprojectTorequest) {
		this.subprojectTorequest = subprojectTorequest;
	}

	
	public HashMap<String, ArrayList<HashMap<String, String>>> getSubprojectTorequestInfo() {
		return subprojectTorequestInfo;
	}

	public void setSubprojectTorequestInfo(
			HashMap<String, ArrayList<HashMap<String, String>>> subprojectTorequestInfo) {
		this.subprojectTorequestInfo = subprojectTorequestInfo;
	}


	public HashMap<String, ArrayList<HashMap<String, String>>> getSubprojectTotaskInfo() {
		return subprojectTotaskInfo;
	}

	public void setSubprojectTotaskInfo(
			HashMap<String, ArrayList<HashMap<String, String>>> subprojectTotaskInfo) {
		this.subprojectTotaskInfo = subprojectTotaskInfo;
	}

	public static String getContractObjID() {
		return contractObjID;
	}

	public void setContractObjID(String contractObjID) {
		SuperBean.contractObjID = contractObjID;
	}

	public static String getOrderStatus() {
		return orderStatus;
	}

	public static void setOrderStatus(String orderStatus) {
		SuperBean.orderStatus = orderStatus;
	}

	public static String getOrderType() {
		return orderType;
	}

	public static void setOrderType(String orderType) {
		SuperBean.orderType = orderType;
	}

	public HashMap<String, String> getService() {
		return service;
	}

	public void setService(HashMap<String, String> service) {
		this.service = service;
	}

	public static String getOrderTitle() {
		return orderTitle;
	}

	public void setOrderTitle(String orderTitle) {
		SuperBean.orderTitle = orderTitle;
	}

	public static String getOrderDate() {
		return orderDate;
	}

	public static void setOrderDate(String orderDate) {
		SuperBean.orderDate = orderDate;
	}

	public static String getExternalID() {
		return externalID;
	}

	public static void setExternalID(String externalID) {
		SuperBean.externalID = externalID;
	}

	public static String getExternalSystem() {
		return externalSystem;
	}

	public void setExternalSystem(String externalSystem) {
		SuperBean.externalSystem = externalSystem;
	}

	public static ArrayList<String> getProvideForModify() {
		return provideForModify;
	}

	public static void setProvideForModify(ArrayList<String> provideForModify) {
		SuperBean.provideForModify = provideForModify;
	}

	public ArrayList<String> getExternalIdColumnNames() {
		return externalIdColumnNames;
	}

	public void setExternalIdColumnNames(ArrayList<String> externalIdColumnNames) {
		this.externalIdColumnNames = externalIdColumnNames;
	}

	public ArrayList<ArrayList> getExternalIds() {
		return externalIds;
	}

	public void setExternalIds(ArrayList<ArrayList> externalIds) {
		this.externalIds = externalIds;
	}

	public int getExternalIdCount() {
		return externalIdCount;
	}

	public void setExternalIdCount(int externalIdCount) {
		this.externalIdCount = externalIdCount;
	}

	public ArrayList<String> getUpdatedRecords() {
		return updatedRecords;
	}

	public void setUpdatedRecords(ArrayList<String> updatedRecords) {
		this.updatedRecords = updatedRecords;
	}

	public ArrayList<ArrayList<String>> getCommercials() {
		return commercials;
	}

	public void setCommercials(ArrayList<ArrayList<String>> commercials) {
		this.commercials = commercials;
	}

	public ArrayList<String> getCommercialColumnNames() {
		return commercialColumnNames;
	}

	public void setCommercialColumnNames(ArrayList<String> commercialColumnNames) {
		this.commercialColumnNames = commercialColumnNames;
	}

	public HashMap<String, ArrayList> getSubprojectTotaskUniqueids() {
		return subprojectTotaskUniqueids;
	}

	public void setSubprojectTotaskUniqueids(
			HashMap<String, ArrayList> subprojectTotaskUniqueids) {
		this.subprojectTotaskUniqueids = subprojectTotaskUniqueids;
	}

	public HashMap<String, HashMap<String,String>> getSubprojectToXMLTask() {
		return subprojectToXMLTask;
	}

	public void setSubprojectToXMLTask(
			HashMap<String, HashMap<String, String>> subprojectToXMLTask) {
		this.subprojectToXMLTask = subprojectToXMLTask;
	}

	public String getXmlType() {
		return xmlType;
	}

	public void setXmlType(String xmlType) {
		this.xmlType = xmlType;
	}

	public static int getEin() {
		return ein;
	}

	public static void setEin(int ein) {
		SuperBean.ein = ein;
	}

	public String getTempSubproject() {
		return tempSubproject;
	}

	public void setTempSubproject(String tempSubproject) {
		this.tempSubproject = tempSubproject;
	}

}
