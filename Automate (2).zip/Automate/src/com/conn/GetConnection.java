package com.conn;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;

import com.Servlet.DataBaseServlet;

public class GetConnection {
	public Connection getConnection(int i) throws SQLException, IOException {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException ex) {
			System.out.println("Error: unable to load driver class!");
			System.exit(1);
		}
		Connection con = null;
		String URL = null;
		String USER = null;
		String PASS = null;

		switch (i) {
		case 1:
			URL = "jdbc:oracle:thin:@172.25.180.68:1521:CLASDEV1";
			USER = "sa";
			PASS = "sa";
			break;
		case 2:
			URL = "jdbc:oracle:thin:@172.25.180.70:1521:CLASDEV2";
			USER = "classic_dev";
			PASS = "classic_dev";
			break;
		case 3:
			URL = "jdbc:oracle:thin:@172.25.180.72:1521:CLASDEV3";
			USER = "sa";
			PASS = "sa";
			break;
		case 4:
			URL = "jdbc:oracle:thin:@172.25.180.98:1521:CLASDEV4";
			USER = "classic_dev";
			PASS = "clarifyv1";
			break;
		case 5:
			URL = "jdbc:oracle:thin:@172.25.180.100:1521:CLASDEV5";
			USER = "sa";
			PASS = "sa";
			break;
		case 6:
			URL = "jdbc:oracle:thin:@172.25.180.102:1521:CLASDEV6";
			USER = "classic_dev";
			PASS = "classic_dev";
			break;
		case 7:
			URL = "jdbc:oracle:thin:@172.25.180.104:1521:CLASDEV7";
			USER = "sa";
			PASS = "sa1426sa";
			break;
		case 8:
			URL = "jdbc:oracle:thin:@172.25.180.106:1521:CLASDEV8";
			USER = "classic_dev";
			PASS = "";
			break;
		case 9:
			URL = "jdbc:oracle:thin:@172.25.180.108:1521:CLASDEV9";
			USER = "classic_dev";
			PASS = "classic_dev";
			break;
		case 10:
			URL = "jdbc:oracle:thin:@172.25.180.110:1521:CLASDEV10";
			USER = "classic_dev";
			PASS = "classic_dev";
			break;
		case 11:
			URL = "jdbc:oracle:thin:@10.80.156.43:1521:CLAST11";
			USER = "classic_dev";
			PASS = "classic_dev";
			break;
		case 22:
			URL = "jdbc:oracle:thin:@10.80.156.44:1521:CLAST2";
			USER = "classic_dev";
			PASS = "clarifyv1";
			break;
		case 33:
			URL = "jdbc:oracle:thin:@10.80.156.41:1521:CLAST31";
			USER = "classic_dev";
			PASS = "classic_dev";
			break;
		case 44 :
			URL = "jdbc:oracle:thin:@10.80.156.41:1521:CLAST31";
			USER = "envcm";
			PASS = "env112";
			break;
		case 0:
			System.exit(0);
		default:
			break;
		}
		try {
			con = DriverManager.getConnection(URL, USER, PASS);
		} catch (Exception ex) {
			return null;
		}
		return con;
	}
}
