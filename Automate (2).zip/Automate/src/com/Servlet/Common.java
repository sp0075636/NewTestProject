package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import SQL.Sqls;

import com.beans.SuperBean;
import java.io.InputStream;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import java.io.IOException;

/*import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;*/

public class Common {
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	ResultSetMetaData rsmd = null;
	// SuperBean bean = new SuperBean();
	PreparedStatement pstmt1 = null;
	ResultSet rs1 = null;

	public void getSubprojects(SuperBean bean, String orderid, Connection conn)
			throws SQLException {
		System.out.println("connected in getSubprojects method...");
		pstmt = conn.prepareStatement(Sqls.SUBPROJECTS);
		ArrayList<String> subprojectColumnNames = new ArrayList<String>();
		ArrayList<String> objid = new ArrayList<String>();
		ArrayList<String> name = new ArrayList<String>();
		ArrayList<String> startDates = new ArrayList<String>();
		pstmt.setString(1, orderid);
		rs = pstmt.executeQuery();
		rsmd = rs.getMetaData();
		int columnsNumber = rsmd.getColumnCount();

		for (int j = 1; j <= columnsNumber; j++) {
			subprojectColumnNames.add(rsmd.getColumnName(j));
		}

		while (rs.next()) {
			objid.add(rs.getString("OBJID"));
			name.add(rs.getString("X_NAME"));
			startDates.add(rs.getString("X_ACTUAL_START_DATE"));
		}
		bean.setSubprojectColumnNames(subprojectColumnNames);
		bean.setSubprojectObjid(objid);
		bean.setSubrojectName(name);
		bean.setSubprojectStartDate(startDates);
		System.out.println("Subprojects in getSubprojects method : "
				+ bean.getSubrojectName());
		System.out
				.println("******************************************Ended Subprojects******************************************");
	}

	public void getTask(SuperBean bean, ArrayList<String> subproObjid,
			Connection conn) throws SQLException {
		System.out.println("connected in getTasks method...");
		String objid;
		ArrayList<String> taskColumnNames = new ArrayList<String>();
		HashMap<String, ArrayList<HashMap<String, String>>> subprojectTotaskInfo = new HashMap<String, ArrayList<HashMap<String, String>>>();
		HashMap<String, ArrayList> subprojectTotasks = new HashMap<String, ArrayList>();
		HashMap<String, ArrayList> subprojectTotaskUniqueids = new HashMap<String, ArrayList>();
		int columnsNumber = 0;
		pstmt = conn.prepareStatement(Sqls.TASKS);
		for (int i = 0; i < subproObjid.size(); i++) {
			ArrayList<HashMap<String, String>> taskNameToobjid = new ArrayList<HashMap<String, String>>();
			if (!(bean.getSubrojectName().get(i).equalsIgnoreCase("Common"))) {
				objid = subproObjid.get(i);
				pstmt.setString(1, objid);
				rs = pstmt.executeQuery();
				rsmd = rs.getMetaData();
				columnsNumber = rsmd.getColumnCount();
				ArrayList<String> taskName = new ArrayList<String>();
				ArrayList<String> temp = new ArrayList<String>();
				ArrayList taskUniqueids = new ArrayList();
				while (rs.next()) {
					HashMap<String, String> objidTotask = new HashMap<String, String>();
					for (int j = 1; j <= columnsNumber; j++) {
						temp.add(rs.getString(j));
					}
					taskUniqueids.add(rs.getString("X_UNIQUE_ID"));
					taskName.add(rs.getString("x_task_id"));
					objidTotask.put(rs.getString("x_task_id"), rs
							.getString("objid"));
					taskNameToobjid.add(objidTotask);
				}
				subprojectTotaskUniqueids.put(objid, taskUniqueids);
				subprojectTotaskInfo.put(bean.getSubrojectName().get(i),
						taskNameToobjid);
				subprojectTotasks.put(bean.getSubrojectName().get(i), temp);
				bean.setSubprojectTotaskUniqueids(subprojectTotaskUniqueids);
				bean.setSubprojectTotasks(subprojectTotasks);
				bean.setSubprojectTotaskInfo(subprojectTotaskInfo);
				System.out.println("Tasks in getTasks method for subproject : "
						+ bean.getSubrojectName().get(i) + " are :" + taskName);
			}
		}
		for (int j = 1; j <= columnsNumber; j++) {
			taskColumnNames.add(rsmd.getColumnName(j));
		}
		bean.setTaskColumnNames(taskColumnNames);
		System.out
				.println("******************************************Ended Tasks******************************************");
	}

	public SuperBean getRequestInstances(SuperBean bean, Connection conn)
			throws SQLException {
		System.out.println("connected in getRequestInstances method...");
		String objid;
		ArrayList<String> requestInstanceColumnNames = new ArrayList<String>();
		HashMap<String, ArrayList> subprojectTorequest = new HashMap<String, ArrayList>();
		HashMap<String, ArrayList<HashMap<String, String>>> subprojectTorequestInfo = new HashMap<String, ArrayList<HashMap<String, String>>>();
		int columnsNumber = 0;
		int counter = 0;
		pstmt = conn.prepareStatement(Sqls.REQUEST_INSTANCES);
		for (int i = 0; i < bean.getSubprojectObjid().size(); i++) {
			ArrayList<HashMap<String, String>> nameToobjid = new ArrayList<HashMap<String, String>>();

			if (!(bean.getSubrojectName().get(i).equalsIgnoreCase("Common"))) {
				objid = bean.getSubprojectObjid().get(i);
				ArrayList<String> requestName = new ArrayList<String>();

				pstmt.setString(1, objid);
				rs = pstmt.executeQuery();
				rsmd = rs.getMetaData();
				columnsNumber = rsmd.getColumnCount();
				while (rs.next()) {
					ArrayList<String> temp = new ArrayList<String>();
					HashMap<String, String> objidTorequest = new HashMap<String, String>();
					for (int j = 1; j <= columnsNumber; j++) {
						temp.add(rs.getString(j));
					}
					objidTorequest.put(rs.getString("REQUEST_ID"), rs
							.getString("REQUEST_OBJID"));
					nameToobjid.add(objidTorequest);
					requestName.add(rs.getString("REQUEST_ID"));
				}
				subprojectTorequestInfo.put(bean.getSubrojectName().get(i),
						nameToobjid);
				bean.setSubprojectTorequest(subprojectTorequest);
				bean.setSubprojectTorequestInfo(subprojectTorequestInfo);
				System.out
						.println("Request instances in getRequestInstances method for subproject : "
								+ bean.getSubrojectName().get(i)
								+ " are :"
								+ requestName);
			}

		}

		for (int j = 1; j <= columnsNumber; j++) {
			requestInstanceColumnNames.add(rsmd.getColumnName(j));
		}
		bean.setRequestInstanceColumnNames(requestInstanceColumnNames);
		System.out
				.println("******************************************Ended request instances******************************************");
		return bean;

	}

	public SuperBean getTaskForSubproject(String subproObjid,
			String subrojectName, Connection conn) throws SQLException {
		System.out.println("connected in getTaskForSubproject method...");
		SuperBean bean = new SuperBean();
		ArrayList<ArrayList> tasks = new ArrayList<ArrayList>();
		ArrayList<String> taskColumnNames = new ArrayList<String>();
		HashMap<String, ArrayList> subprojectTotasks = new HashMap<String, ArrayList>();
		int columnsNumber = 0;
		pstmt = conn.prepareStatement(Sqls.TASKS);

		if (!(subrojectName.equalsIgnoreCase("Common"))) {
			ArrayList<String> taskName = new ArrayList<String>();
			pstmt.setString(1, subproObjid);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			columnsNumber = rsmd.getColumnCount();
			while (rs.next()) {
				ArrayList<String> temp = new ArrayList<String>();
				for (int j = 1; j <= columnsNumber; j++) {
					temp.add(rs.getString(j));
				}
				tasks.add(temp);
				taskName.add(rs.getString("x_task_id"));
			}
			subprojectTotasks.put(subrojectName, tasks);

			bean.setSubprojectTotasks(subprojectTotasks);
			System.out
					.println("Tasks in getTaskForSubproject method for subproject : "
							+ subrojectName + " are :" + taskName);
		}
		for (int j = 1; j <= columnsNumber; j++) {
			taskColumnNames.add(rsmd.getColumnName(j));
		}
		bean.setTaskColumnNames(taskColumnNames);
		ArrayList<String> requestInstanceColumnNames = new ArrayList<String>();
		HashMap<String, ArrayList> subprojectTorequest = new HashMap<String, ArrayList>();
		int counter = 0;
		pstmt = conn.prepareStatement(Sqls.REQUEST_INSTANCES);
		pstmt.setString(1, subproObjid);
		rs = pstmt.executeQuery();
		rsmd = rs.getMetaData();
		columnsNumber = rsmd.getColumnCount();
		ArrayList<ArrayList> requestInst = new ArrayList<ArrayList>();
		if (!(subrojectName.equalsIgnoreCase("Common"))) {
			ArrayList<String> requestName = new ArrayList<String>();
			while (rs.next()) {
				ArrayList<String> temp = new ArrayList<String>();
				for (int j = 1; j <= columnsNumber; j++) {
					temp.add(rs.getString(j));
				}
				requestInst.add(temp);
			}
			subprojectTorequest.put(subrojectName, requestInst);
			bean.setSubprojectTorequest(subprojectTorequest);
			System.out
					.println("Request instances in getTaskForSubproject method for subproject : "
							+ subrojectName + " are :" + requestName);
		}
		for (int j = 1; j <= columnsNumber; j++) {
			requestInstanceColumnNames.add(rsmd.getColumnName(j));
		}
		bean.setRequestInstanceColumnNames(requestInstanceColumnNames);
		System.out
				.println("******************************************Ended getTaskForSubproject******************************************");
		return bean;
	}

	public void getExternalID(SuperBean bean, String orderId, Connection conn)
			throws SQLException {
		System.out.println("connected in getExternalID method...");
		ArrayList<String> externalColumnNames = new ArrayList<String>();
		PreparedStatement pstmt = conn
				.prepareStatement(Sqls.GET_ALL_EXTERNAL_IDS);
		pstmt.setString(1, orderId);
		ResultSet rs = pstmt.executeQuery();
		ResultSetMetaData rsmd = rs.getMetaData();
		int columnsNumber = rsmd.getColumnCount();
		int count = 0;
		for (int j = 1; j <= columnsNumber; j++) {
			externalColumnNames.add(rsmd.getColumnName(j));
		}
		bean.setExternalIdColumnNames(externalColumnNames);
		ArrayList<ArrayList> externalIds = new ArrayList<ArrayList>();
		System.out.println("External Ids in getExternalID method for Order "
				+ orderId + " are : ");
		while (rs.next()) {
			ArrayList<String> temp = new ArrayList<String>();
			for (int j = 1; j <= columnsNumber; j++) {
				temp.add(rs.getString(j));
			}
			System.out.println(temp);
			count++;
			externalIds.add(temp);
		}
		bean.setExternalIdCount(count);
		bean.setExternalIds(externalIds);
		System.out
				.println("******************************************Ended getExternalID******************************************");
	}

	public String formatDate(String date) {
		try {
			DateFormat formatter;
			if (date.contains("/")) {
				formatter = new SimpleDateFormat("dd/MM/yyyy");
			} else {
				formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			}
			DateFormat formatter1 = new SimpleDateFormat("yyyyMMdd");

			Date format = formatter.parse(date);
			date = formatter1.format(format);
		} catch (ParseException e) {
			System.out.println("formatDate: PARSING UPDATABLE FIELDS " + e);
		}
		return date;
	}

	public String getEnv(int i) {
		String env = null;
		if (i < 11) {
			env = "CLASDEV" + i;
		} else {
			env = "CLAST" + (i % 10);
		}
		return env;

	}

	public boolean mailXML(String input, String time, String ip, String uname,
			String path, String env) throws IOException, ServletException,
			InterruptedException {
		/*String scriptName = "/wls_domains/wlstahiti07/applications/XML_mail.sh";
		String commands = "/wls_domains/wlstahiti07/applications/XML_mail.sh"
				+ " \"" + input + "\" \"" + time + "\" \"" + ip + "\" \""
				+ uname + "\" \"" + path + "\" \"" + env + "\"";
		String commands="C:\\Users\\609128143\\Documents\\My Received Files\\svn_auto_update.bat";
		Runtime rt = Runtime.getRuntime();
		Process process = null;
		try {
			process = rt.exec(commands);
			// process.waitFor();
			return true;
		} catch (Exception e) {
			return false;
		}*/
		Runtime runtime = Runtime.getRuntime();
		try {
			String commands = "/wls_domains/wlstahiti07/applications/XML_mail.sh"
				+ " \"" + input + "\" \"" + time + "\" \"" + ip + "\" \""
				+ uname + "\" \"" + path + "\" \"" + env + "\"";
		    Process p = runtime.exec(commands);
		    InputStream is = p.getInputStream();
		    int i = 0;
		    while( (i = is.read() ) != -1) {
		        System.out.print((char)i);
		    }
		    return true;
		} catch(IOException ioException) {
		    System.out.println(ioException.getMessage() );
		    return false;
		}
		/*
		 * ProcessBuilder pb = new ProcessBuilder(scriptName, input, time, ip,
		 * uname,path, env); try { Process proc = pb.start(); Runtime rt =
		 * Runtime.getRuntime(); Process process = null; process =
		 * rt.exec(commands); process.waitFor(); return true; } catch
		 * (IOException e) { HttpServletRequest req=null; HttpServletResponse
		 * res=null; PrintWriter out = res.getWriter(); // TODO Auto-generated
		 * catch block RequestDispatcher rd =
		 * req.getRequestDispatcher("AnyOrderXML.jsp"); out.print("<center><i>Error
		 * !!!</i></center>"); rd.include(req, res); return false; }
		 */

	}

	public boolean SSHClient(String input, String time, String ip,
			String uname, String path, String env) throws IOException,
			ServletException {
		String host = "172.25.180.76";
		String user = "palankp";
		String password1 = "baby@2312";
		String command1 = "/wls_domains/wlstahiti07/applications/XML_mail.sh"
				+ " \"" + input + "\" \"" + time + "\" \"" + ip + "\" \""
				+ uname + "\" \"" + path + "\" \"" + env + "\"";
		try {

			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			Session session = jsch.getSession(user, host, 22);
			session.setPassword(password1);
			session.setConfig(config);
			session.connect();
			System.out.println("Connected");

			Channel channel = session.openChannel("exec");
			((ChannelExec) channel).setCommand(command1);
			channel.setInputStream(null);
			((ChannelExec) channel).setErrStream(System.err);

			InputStream in = channel.getInputStream();
			channel.connect();
			byte[] tmp = new byte[1024];
			while (true) {
				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);
					if (i < 0)
						break;
					System.out.print(new String(tmp, 0, i));
				}
				if (channel.isClosed()) {
					System.out.println("exit-status: "
							+ channel.getExitStatus());
					break;
				}
				try {
					Thread.sleep(1000);
				} catch (Exception ee) {
				}
			}
			channel.disconnect();
			session.disconnect();
			System.out.println("DONE");
			return true;
		} catch (Exception e) {
			return false;
		}

	}
 /*public void runScript(String input, String time, String ip,
			String uname, String path, String env){
	 String sCommandString = "/wls_domains/wlstahiti07/applications/XML_mail.sh"
			+ " \"" + input + "\" \"" + time + "\" \"" + ip + "\" \""
			+ uname + "\" \"" + path + "\" \"" + env + "\"";
	 int iExitValue;
	        CommandLine oCmdLine = CommandLine.parse(sCommandString);
	        DefaultExecutor oDefaultExecutor = new DefaultExecutor();
	        oDefaultExecutor.setExitValue(0);
	        try {
	            iExitValue = oDefaultExecutor.execute(oCmdLine);
	        } catch (ExecuteException e) {
	            System.err.println("Execution failed.");
	            e.printStackTrace();
	        } catch (IOException e) {
	            System.err.println("permission denied.");
	            e.printStackTrace();
	        }
	    }*/

}
