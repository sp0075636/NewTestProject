package com.Servlet;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.SuperBean;

import SQL.Sqls;

/**
 * Servlet implementation class for Servlet: TechnicalInfo
 *
 */
 public class ElementInfo extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {
   
   
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		System.out.println("Connected in TechnicalInfo...");
		SuperBean bean=new SuperBean();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		ArrayList<ArrayList<String>> technicalElements=new ArrayList<ArrayList<String>>();	
		ArrayList<String> technicalElementColumnNames = new ArrayList<String>();		
		try {
			pstmt = bean.connection.prepareStatement(Sqls.TECHNICALS);
			pstmt.setString(1, bean.orderid);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int columnsNumber = rsmd.getColumnCount();
			for (int j = 1; j <= columnsNumber; j++) {
				technicalElementColumnNames.add(rsmd.getColumnName(j));
			}
			bean.setTechnicalColumnNames(technicalElementColumnNames);
			System.out.println("Technical Elements :");
			while (rs.next()) {
				ArrayList<String> temp=new ArrayList<String>();
				temp.add(rs.getString(1));
				temp.add(rs.getString(2));
				temp.add(rs.getString(3));
				temp.add(rs.getString(4));
				temp.add(rs.getString(5));
				temp.add(rs.getString(6));
				System.out.println(temp);
				technicalElements.add(temp);
			}
			bean.setTechnicals(technicalElements);
			ArrayList<ArrayList<String>> commercialElements=new ArrayList<ArrayList<String>>();	
			ArrayList<String> commericalElementColumnNames = new ArrayList<String>();		
			pstmt.close();
			rs.close();
			if(bean.getOrderType().equalsIgnoreCase("Add")){
				pstmt = bean.connection.prepareStatement(Sqls.COMMERCIALS_FOR_PROVIDE);
				pstmt.setString(1, bean.orderid);
			}else{
				pstmt = bean.connection.prepareStatement(Sqls.COMMERCIALS_FOR_MODIFY);
				pstmt.setString(1, bean.orderid);
			}
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			columnsNumber = rsmd.getColumnCount();
			for (int j = 1; j <= columnsNumber; j++) {
				commericalElementColumnNames.add(rsmd.getColumnName(j));
			}
			bean.setCommercialColumnNames(commericalElementColumnNames);
			System.out.println("Commercial Elements :");
			while (rs.next()) {
				ArrayList<String> temp=new ArrayList<String>();
				temp.add(rs.getString(1));
				temp.add(rs.getString(2));
				temp.add(rs.getString(3));
				temp.add(rs.getString(4));
				temp.add(rs.getString(5));
				temp.add(rs.getString(6));
				System.out.println(temp);
				commercialElements.add(temp);
			}
			bean.setCommercials(commercialElements);
			pstmt.close();
			rs.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		req.setAttribute("bean", bean);
		RequestDispatcher rd = req.getRequestDispatcher("ElementInfo.jsp");
		rd.forward(req, res);
	}   	  	    
}