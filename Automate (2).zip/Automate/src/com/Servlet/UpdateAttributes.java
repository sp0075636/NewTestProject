package com.Servlet;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.SuperBean;

import SQL.Sqls;

/**
 * Servlet implementation class for Servlet: UpdateAttributes
 * 
 */
public class UpdateAttributes extends javax.servlet.http.HttpServlet implements
		javax.servlet.Servlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		GetSubprojects gsp = new GetSubprojects();
		ArrayList updatedRecords = new ArrayList();
		String SitePart = null;
		String PartAttrib = null;
		SuperBean bean = new SuperBean();
		try {
			PreparedStatement pstmt = bean.connection
					.prepareStatement(Sqls.UPDATE_ATTRIBUTE);
			CallableStatement cstmt = bean.connection
					.prepareCall("{call UPDATE_SR(?,?,?,?,'0')}");
			String attributeObjid = req.getParameter("attributes");
			String attribValue = req.getParameter("value");
			System.out.println("Entered attributeObjid : " + attributeObjid
					+ " value : " + attribValue);
			int u = 0;			
				if (SuperBean.getI() > 10) {
					cstmt.setString(1, "TABLE_X_INST_ATTRIB_VALUE");
					cstmt.setString(2, "X_VALUE");
					if (attribValue == null || "null".equalsIgnoreCase(attribValue)) 
						cstmt.setString(3, null);
					else
						cstmt.setString(3, attribValue);
					cstmt.setString(4, attributeObjid);
					u = cstmt.executeUpdate();
				} else {
					if (attribValue == null || "null".equalsIgnoreCase(attribValue)) 
						pstmt.setString(1, null);
					else
						pstmt.setString(1, attribValue);
					pstmt.setString(2, attributeObjid);
					u = pstmt.executeUpdate();
				}
			
			pstmt.close();
			pstmt = bean.connection.prepareStatement(Sqls.ATTRIBUTE_FROM_INST);
			pstmt.setString(1, attributeObjid);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				if (u == 1) {
					updatedRecords.add("Updated Attribute : "
							+ rs.getString("X_DESCRIPTION") + " with value : "
							+ attribValue);
					pstmt.close();
					rs.close();
					pstmt = SuperBean.getConnection().prepareStatement(
							Sqls.ORDER_TITLE);
					pstmt.setString(1, bean.orderid);
					rs = pstmt.executeQuery();
					String orderStatus = null;
					if (rs.next()) {
						orderStatus = rs.getString("STATUS");
					}
					pstmt.close();
					rs.close();
					if (orderStatus.contains("Closed")) {
						pstmt=bean.connection.prepareStatement(Sqls.ATTRIBUTE_PART_SITE_INFO);
						pstmt.setString(1, attributeObjid);
						rs=pstmt.executeQuery();
						if(rs.next()){
							PreparedStatement pstmt1 = bean.connection
							.prepareStatement(Sqls.UPDATE_HIST_TABLE);
							if (attribValue == null || "null".equalsIgnoreCase(attribValue)) 
								pstmt1.setString(1, null);
							else
								pstmt1.setString(1, attribValue);
							pstmt1.setString(2, rs.getString("PART_ATTRIB"));
							pstmt1.setString(3, rs.getString("SITE_PART"));
							int s = pstmt1.executeUpdate();
							if(s==1){
							updatedRecords.add("Updated TABLE_X_IAV_HIST : "
									+ " with value : "
									+ attribValue);
							}
							pstmt1.close();
						}
					}
					bean.connection.commit();
					bean.setUpdatedRecords(updatedRecords);
				}
			}
			Home home = new Home();
			home.doPost(req, res);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}