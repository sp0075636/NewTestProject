package com.Servlet;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;

import com.beans.SuperBean;

public class DownloadServlet extends HttpServlet {

public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	SuperBean bean = new SuperBean();
	int ein=bean.getEin();
	String orderid=bean.getOrderid();
response.setContentType("text/html");
PrintWriter out = response.getWriter();
String filename = "home.jsp"; 
String filepath = "C:\\Users\\"+ein+"\\Documents\\"; 
response.setContentType("APPLICATION/OCTET-STREAM"); 
response.setHeader("Content-Disposition","attachment; filename=\"" + filename + "\""); 

FileInputStream fileInputStream = new FileInputStream(filepath + filename);
		  
int i; 
while ((i=fileInputStream.read()) != -1) {
out.write(i); 
} 
fileInputStream.close(); 
out.close(); 
}

}


