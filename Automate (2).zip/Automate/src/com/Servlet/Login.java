package com.Servlet;

import com.beans.SuperBean;
import com.conn.GetConnection;
import SQL.Sqls;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login extends javax.servlet.http.HttpServlet implements
		javax.servlet.Servlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		SuperBean bean = new SuperBean();
		RequestDispatcher rd = null;
		int ein = 0;
		String pass = null;
		PrintWriter out = res.getWriter();
		try {
			ein = Integer.parseInt(req.getParameter("ein"));
			pass = req.getParameter("pswrd");
			System.out.println("Recieved Ein :" + ein + " and pswrd :" + pass);
		} catch (Exception e) {
			out.print("<center><i>Invalid Details !!!</i></center>");
			rd = req.getRequestDispatcher("index.jsp");
			rd.include(req, res);
		}
		try {

			GetConnection gc = new GetConnection();
			Connection con = gc.getConnection(44);
			PreparedStatement pstmt = con.prepareStatement(Sqls.LOGIN_VALIDATE);
			pstmt.setInt(1, ein);
			pstmt.setString(2, pass);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				bean.setEin(ein);
				rd = req.getRequestDispatcher("SelectEnv.jsp");
				rd.forward(req, res);
			} else {
				out.print("<center><i>Invalid Credentials !!!</i></center>");
				rd = req.getRequestDispatcher("index.jsp");
				rd.include(req, res);
			}
		} catch (SQLException e) {
			out.print("<center><i>Check Connection Details !!!</i></center>");
			rd = req.getRequestDispatcher("index.jsp");
			rd.include(req, res);
		}

	}
}