package com.Servlet;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.SuperBean;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import SQL.Sqls;

/**
 * Servlet implementation class for Servlet: GetXMLs
 * 
 */
public class GetXMLs extends javax.servlet.http.HttpServlet implements
		javax.servlet.Servlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = res.getWriter();
		SuperBean bean = new SuperBean();
		int ein=bean.getEin();
		Connection conn = bean.connection;
		String orderid=bean.getOrderid();
		RequestDispatcher rd = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String taskObjid = req.getParameter("gettask");
		String taskID = null;
		ArrayList<String> MLP = new ArrayList<String>() {
			{
				add("P06.06");
				add("M06.06");
			}
		};
		ArrayList<String> MRS = new ArrayList<String>() {
			{
				add("P02.01");
				add("M02.01");
				add("P02.09");
			}
		};
		ArrayList<String> CLASSIC2AIB = new ArrayList<String>() {
			{
				add("P06.62");
				add("M06.62");
			}
		};
		System.out.println("taskObjid recieved in GetXMLs is : " + taskObjid);
		try {
			pstmt = conn.prepareStatement(Sqls.TASK_NAME);
			pstmt.setString(1, taskObjid);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				taskID = rs.getString("X_UNIQUE_ID");
			}
			String messageID_Req = null;
			String messageID_Res = null;
			String messageMLP = null;
			String MLPSave = null;
			
				if (MLP.contains(taskID)) { // MLP
					pstmt = conn.prepareStatement(Sqls.GET_MLP_MESSAGE_ID);
					pstmt.setString(1, taskObjid);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						messageMLP = rs.getString("X_MESSAGEID");
						if(messageMLP!=null){
						if (messageMLP.contains("Classic/"))
							MLPSave = messageMLP.substring(8, messageMLP
									.length());
						else
							MLPSave = messageMLP;
						}
					}
					pstmt = conn
							.prepareStatement(Sqls.GET_MESSAGE_REQUEST_XML_FROM_MESSAGE_ID);
					pstmt.setString(1, messageMLP);
				} else if (MRS.contains(taskID) || CLASSIC2AIB.contains(taskID)) { // MRS,CLASSIC2AIB
					pstmt = conn
							.prepareStatement(Sqls.GET_MESSAGE_REQUEST_XML_FROM_TASK);
					pstmt.setString(1, taskObjid);
				}
				
				rs = pstmt.executeQuery();
				while (rs.next()) {
					messageID_Req = rs.getString("X_MESSAGEID");
					if (messageID_Req != null) {
						File data = null;
						data=new File("C:\\Users\\"+ein+"\\Documents\\"+orderid);
					    if (!data.exists()) {
					        if (data.mkdir()) {
					            System.out.println("Directory is created!");
					        } else {
					            System.out.println("Failed to create directory!");
					        }
					    }
					    else{
					    	 System.out.println("Directory exists!");
					    }
						if (MRS.contains(taskID))
							data = new File("C:\\Users\\"+ein+"\\Documents\\"+orderid+"\\"
									+ messageID_Req + "_MRS_Request.xml");
						else if (CLASSIC2AIB.contains(taskID))
							data = new File("C:\\Users\\"+ein+"\\Documents\\"
									+ messageID_Req + "_AIB_Request.xml");
						else if (MLP.contains(taskID))
							data = new File("C:\\Users\\"+ein+"\\Documents\\"+orderid+"\\"
									+ MLPSave + "_MLP_Request.xml");
						Reader reader = rs.getCharacterStream("X_XML");
						FileWriter writer = new FileWriter(data);
						char[] buffer = new char[1];
						while (reader.read(buffer) > 0) {
							writer.write(buffer);
						}
						writer.close();
					}

				}

				if (messageID_Req != null) {
					pstmt = conn
							.prepareStatement(Sqls.GET_MESSAGE_RESPONSE_XML);
					pstmt.setString(1, messageID_Req);
					rs = pstmt.executeQuery();
					while (rs.next()) {
						messageID_Res = rs.getString("X_RELATESTO");
						if (messageID_Res != null) {
							File data = null;
							if (MRS.contains(taskID))
								data = new File(
										"C:\\Users\\"+ein+"\\Documents\\"+orderid+"\\"
												+ messageID_Req
												+ "_MRS_Response.xml");
							else if (CLASSIC2AIB.contains(taskID))
								data = new File(
										"C:\\Users\\"+ein+"\\Documents\\"+orderid+"\\"
												+ messageID_Req
												+ "_AIB_Response.xml");
							else if (MLP.contains(taskID))
								data = new File(
										"C:\\Users\\"+ein+"\\Documents\\"+orderid+"\\"
												+ MLPSave + "_MLP_Response.xml");
							Reader reader = rs.getCharacterStream("X_XML");
							FileWriter writer = new FileWriter(data);
							char[] buffer = new char[1];
							while (reader.read(buffer) > 0) {
								writer.write(buffer);
							}
							writer.close();
						}
					}
				}

				if (messageID_Req != null) {
					if (MRS.contains(taskID)) {
						out
								.print("<center><i>Request XML saved at C:\\Users\\"+ein+"\\Documents\\"+orderid+"\\"
										+ messageID_Req
										+ "_MRS_Request.xml </i></center>");
						if (messageID_Res != null)
							out
									.print("<center><i>Response XML saved at C:\\Users\\"+ein+"\\Documents\\"+orderid+"\\"
											+ messageID_Res
											+ "_MRS_Response.xml </i></center>");
						else
							out
									.print("<center><i>Request Sent but response not received!!!</i></center>");
					} else if (MLP.contains(taskID)) {
						out
								.print("<center><i>Request XML saved at C:\\Users\\"+ein+"\\Documents\\"+orderid+"\\"
										+ MLPSave
										+ "_MLP_Request.xml </i></center>");
						if (messageID_Res != null)
							out
									.print("<center><i>Response XML saved at C:\\Users\\"+ein+"\\Documents\\"+orderid+"\\"
											+ MLPSave
											+ "_MLP_Response.xml </i></center>");
						else
							out
									.print("<center><i>Request Sent but response not received!!!</i></center>");
					} else if (CLASSIC2AIB.contains(taskID)) {
						out
								.print("<center><i>Request XML saved at C:\\Users\\"+ein+"\\Documents\\"+orderid+"\\"
										+ messageID_Req
										+ "_AIB_Request.xml </i></center>");
						if (messageID_Res != null)
							out
									.print("<center><i>Response XML saved at C:\\Users\\"+ein+"\\Documents\\"+orderid+"\\"
											+ messageID_Req
											+ "_AIB_Response.xml </i></center>");
						else
							out
									.print("<center><i>Request Sent but response not received!!!</i></center>");
					}
				} else {
					out.print("<center><i>Request Not Sent!!!</i></center>");
				}
			
			Home home = new Home();
			home.doPost(req, res);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			Home home = new Home();
			out.print("<center><i>Request Not sent !!</i></center>");
			home.doPost(req, res);
		}
	}
}