package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.StringTokenizer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.conn.GetConnection;
import SQL.Sqls;

public class AnyOrderXML extends javax.servlet.http.HttpServlet implements
		javax.servlet.Servlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		res.setContentType("text/html");
		Common comm = new Common();
		RequestDispatcher rd = null;
		GetConnection gc = new GetConnection();
		try {
			Connection con = gc.getConnection(7);
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			PrintWriter out = res.getWriter();
			String expid = req.getParameter("expid");
			String env = comm.getEnv(Integer.parseInt(req.getParameter("env")));// req.getParameter("env")
			String orderType = req.getParameter("ordertype");
			String time = comm.formatDate(req.getParameter("time"));
			String email = req.getParameter("email");
			String boxType = null;
			String ip = null;
			String username = null;
			String xmlPath = null;
			if (env.contains("DEV")) {
				boxType = "Weblogic";
			} else {
				boxType = orderType;
			}
			if (expid != null || email != null || time != null || email != null) {
				ArrayList details=this.getEnvDetails(orderType, env, boxType);
				ip=(String) details.get(0);
				username=(String) details.get(1);
				xmlPath=(String) details.get(2);
				System.out.println(expid + " , " + time + " , " + ip + " , "
						+ username + " , " + xmlPath + " , " + env);
				
					boolean bool = false;
					try {
						bool = comm.mailXML(expid, time, ip, username, xmlPath, env);
					} catch (InterruptedException e) {
						rd = req.getRequestDispatcher("AnyOrderXML.jsp");
						out
								.print("<center><i>Error!!!</i></center>");
						rd.include(req, res);
					}
				if(bool==true){
				rd = req.getRequestDispatcher("AnyOrderXML.jsp");
				out.print("<center><i>XML sent in email !!!</i></center>");
				rd.include(req, res);
				}else {
					rd = req.getRequestDispatcher("AnyOrderXML.jsp");
					out
							.print("<center><i>Error!!!</i></center>");
					rd.include(req, res);
				}
			} else {
				rd = req.getRequestDispatcher("AnyOrderXML.jsp");
				out
						.print("<center><i>Please fill all the fields !!!</i></center>");
				rd.include(req, res);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public ArrayList getEnvDetails(String orderType, String env, String boxType)
			throws IOException {
		GetConnection gc = new GetConnection();
		ArrayList al = new ArrayList();
		try {
			Connection con = gc.getConnection(7);
			PreparedStatement pstmt = null;
			ResultSet rs = null;
			pstmt = con.prepareStatement(Sqls.XML_DETAILS);
			pstmt.setString(1, orderType);
			pstmt.setString(2, env);
			pstmt.setString(3, boxType);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				al.add(rs.getString("IP"));
				al.add(rs.getString("UNAME"));
				al.add(rs.getString("PATH"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return al;
	}
}