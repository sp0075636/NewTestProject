package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import SQL.Sqls;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.SuperBean;

/**
 * Servlet implementation class for Servlet: RetreveOrderXML
 * 
 */
public class RetreveOrderXML extends javax.servlet.http.HttpServlet implements
		javax.servlet.Servlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		Common comm=new Common();
		AnyOrderXML aox=new AnyOrderXML();
		SuperBean bean = new SuperBean();		
		String input = req.getParameter("XML");
		String email = req.getParameter("email");
		String date = comm.formatDate(bean.getOrderDate());
		String expid=bean.getExternalID();
		ArrayList emails = new ArrayList();
		Common info = new Common();
		RequestDispatcher rd = null;
		String orderid = bean.orderid;
		Connection conn = bean.connection;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String orderType=bean.getExternalSystem();
		if(orderType.equalsIgnoreCase("eDCA")) orderType="eDCA";
		else	orderType=orderType+"-"+bean.getOrderType();
		try {
			info.getSubprojects(bean, orderid, conn);
			info.getTask(bean, bean.getSubprojectObjid(), conn);
			info.getRequestInstances(bean, conn);
			info.getExternalID(bean, orderid, conn);			
			HashMap<String, ArrayList> subprojectTotaskUniqueids = bean
					.getSubprojectTotaskUniqueids();
			bean.setXmlType(input);
			if (input.equalsIgnoreCase("Order Upload XML")) {
				String boxType = null;
				if (bean.getEnv().contains("DEV")) {
					boxType = "Weblogic";
				} else {
					boxType = bean.getOrderType();
				}
				ArrayList details=aox.getEnvDetails(orderType, bean.getEnv(), boxType);
				String ip=(String) details.get(0);
				String username=(String) details.get(1);
				String xmlPath=(String) details.get(2);
				if (email.contains(",")) {
					StringTokenizer st = new StringTokenizer(email, ",");
					while (st.hasMoreTokens()) {
						emails.add(st.nextToken());
					}

				}		
				try {
					comm.mailXML(expid, date, ip, username, xmlPath,bean.getEnv());
					
				} catch (InterruptedException e1) {
					// TODO Auto-generated catch block
					rd = req.getRequestDispatcher("AnyOrderXML.jsp");
					out.print("<center><i>Error in mriggering mail !!!</i></center>");
					rd.include(req, res);
				}
				try {					
					System.out.println("Date to be searched for order:" + date);
					/*String scriptName = "/wls_domains/wlstahiti07/applications/XML_mail.sh";
					String commands[] = new String[] { scriptName, "myArg1",
							"myArg2" }; // email,env,order
					// type(provide,modify),order date,

					Runtime rt = Runtime.getRuntime();
					Process process = null;
					try {
						process = rt.exec(commands);
						process.waitFor();
					} catch (Exception e) {
						e.printStackTrace();
					}*/
					req.setAttribute("bean", bean);
					out.print("<center><i>Mail sent !!</i></center>");	
					rd = req.getRequestDispatcher("SelectXML.jsp");
					rd.include(req, res);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					out.print("<center><i>Error in Finding XML !!! !!</i></center>");	
					Home home=new Home();
					home.doPost(req, res);
				}
			} else if (input.equalsIgnoreCase("MLP")
					|| input.equalsIgnoreCase("MRS")
					|| input.equalsIgnoreCase("CLASSIC-AIB")) {

				HashMap<String, HashMap<String, String>> subprojectToXMLTask = new HashMap<String, HashMap<String, String>>(); // {subproj_objid,{task_objid,task_info}}
				Set set = subprojectTotaskUniqueids.entrySet();
				Iterator itr = set.iterator();
				String taskId = null;
				String subproName = null;
				while (itr.hasNext()) {
					Map.Entry me = (Map.Entry) itr.next();
					pstmt = conn
							.prepareStatement(Sqls.GET_SUBPROJECT_NAME_FROM_OBJID);
					pstmt.setString(1, (String) me.getKey());
					rs = pstmt.executeQuery();

					if (rs.next())
						subproName = rs.getString("X_NAME");
					System.out.println("For Subproject : " + subproName
							+ " Task Unique Id's are  : " + me.getValue());
					ArrayList tasks = (ArrayList) me.getValue();
					if (input.equalsIgnoreCase("MLP")) {
						if (tasks.contains("P06.06"))
							taskId = "P06.06"; // Prepare & build CPE base
						// config (Provide)
						if (tasks.contains("M06.06"))
							taskId = "M06.06"; // Prepare & build CPE base
						// config (Change)
					} else if (input.equalsIgnoreCase("MRS")) {
						if (tasks.contains("P02.01"))
							taskId = "P02.01"; // Plan & Assign Primary Global
						// Network Resource (Provide)
						if (tasks.contains("M02.01"))
							taskId = "M02.01"; // Plan & Assign Primary Global
						// Network Resource (Change)
						if (tasks.contains("P02.09"))
							taskId = "P02.09"; // Automatic Port Allocation
					} else if (input.equalsIgnoreCase("CLASSIC-AIB")) {
						if (tasks.contains("P06.62"))
							taskId = "P06.62"; // Automatic Deliver CPE
						// (Provide)
						if (tasks.contains("M06.62"))
							taskId = "M06.62"; // Automatic Deliver CPE
						// (Change)
					}

					if (taskId != null) {
						pstmt = conn
								.prepareStatement(Sqls.GET_TASK_FROM_UNIQUE_ID);
						pstmt.setString(1, (String) me.getKey());
						pstmt.setString(2, taskId);
						rs = pstmt.executeQuery();
						while (rs.next()) { // OBJID,X_TASK_ID,X_STATUS,X_ACTUAL_START_DATE,X_UNIQUE_ID
							HashMap<String, String> taskObjidtoDetails = new HashMap<String, String>();
							String taskDetails = rs.getString("X_TASK_ID")
									+ " - " + rs.getString("X_STATUS") + " - "
									+ rs.getString("X_ACTUAL_START_DATE");
							taskObjidtoDetails.put(rs.getString("OBJID"),
									taskDetails);
							subprojectToXMLTask.put(subproName,
									taskObjidtoDetails);
						}
					}
				}
				if (taskId != null) {
					bean.setSubprojectToXMLTask(subprojectToXMLTask);
					req.setAttribute("bean", bean);
					rd = req.getRequestDispatcher("SelectXMLTask.jsp");
					rd.include(req, res);
				} else {
					out
							.println("<center><i> No Specific task found in subproject "
									+ subproName
									+ " for "
									+ input
									+ " Request</i></center></br>");
					req.setAttribute("bean", bean);
					rd = req.getRequestDispatcher("SelectXML.jsp");
					rd.include(req, res);
				}

			} else if (input.equalsIgnoreCase("GFS")) {
				req.setAttribute("bean", bean);
				rd = req.getRequestDispatcher("SelectXMLTask.jsp");
				rd.include(req, res);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}