package com.Servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.SuperBean;

public class ViewTasks extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		SuperBean bean = new SuperBean();
		String subprojObjid = null;
		String subprojName = null;
		Common info = new Common();
		Connection con = SuperBean.connection;
		res.setContentType("text/html");
		subprojObjid = req.getParameter("getsubproject");
		System.out.println("recieved subproject id in ViewTasks is  : " + subprojObjid);
		String query = "select x_name from table_x_subproject where objid=?";
		try {
			PreparedStatement psmt = con.prepareStatement(query);
			psmt.setString(1, subprojObjid);
			ResultSet rs = psmt.executeQuery();			
			if(rs.next()) 
				subprojName=rs.getString("x_name");
			bean = info.getTaskForSubproject(subprojObjid,subprojName, con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		bean.setTempSubproject(subprojObjid);
		req.setAttribute("bean", bean);
		RequestDispatcher rd = req.getRequestDispatcher("Tasks.jsp");
		rd.forward(req, res);
	}
}
