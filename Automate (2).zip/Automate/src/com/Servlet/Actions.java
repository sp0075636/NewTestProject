package com.Servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.SuperBean;
import SQL.Sqls;

public class Actions extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = null;
		GetSubprojects gsp = new GetSubprojects();
		String option = req.getParameter("option");
		Common info = new Common();
		SuperBean bean = new SuperBean();
		if (option.equalsIgnoreCase("end")) {
			try {
				info.getSubprojects(bean, bean.orderid, bean.connection);
				info.getTask(bean, bean.getSubprojectObjid(),
						bean.connection);
				info.getRequestInstances(bean, bean.connection);
				HashMap<String, ArrayList<HashMap<String, String>>> tasks = bean
						.getSubprojectTotaskInfo();
				ArrayList<String> subprojectObjid = bean.getSubprojectObjid();
				for (int i = 0; i < subprojectObjid.size(); i++) {
					if (!(bean.getSubrojectName().get(i)
							.equalsIgnoreCase("Common"))) {
						ArrayList<HashMap<String, String>> taskinfo = tasks
								.get(bean.getSubrojectName().get(i));
					}
				}
				HashMap<String, ArrayList<HashMap<String, String>>> request = bean
						.getSubprojectTorequestInfo();
				for (int i = 0; i < subprojectObjid.size(); i++) {
					if (!(bean.getSubrojectName().get(i)
							.equalsIgnoreCase("Common"))) {
						ArrayList<HashMap<String, String>> taskinfo = request
								.get(bean.getSubrojectName().get(i));
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			req.setAttribute("bean", bean);
			rd = req.getRequestDispatcher("UpdateTask.jsp");
			rd.forward(req, res);
		}else{			
			Connection con = SuperBean.connection;
			String subprojName = null;
			System.out.println("recieved subproject id in ViewTasks is  : " + option);
			bean.setTempSubproject(option);
			String query = "select x_name from table_x_subproject where objid=?";
			try {
				PreparedStatement psmt = con.prepareStatement(query);
				psmt.setString(1, option);
				ResultSet rs = psmt.executeQuery();			
				if(rs.next()) 
					subprojName=rs.getString("x_name");
				bean = info.getTaskForSubproject(option,subprojName, con);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			req.setAttribute("bean", bean);
			rd = req.getRequestDispatcher("Tasks.jsp");
			rd.forward(req, res);
			
		}
	}
}
