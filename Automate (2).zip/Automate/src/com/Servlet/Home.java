package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.SuperBean;

/**
 * Servlet implementation class for Servlet: Home
 * 
 */
public class Home extends javax.servlet.http.HttpServlet implements
		javax.servlet.Servlet {
	ArrayList<String> updatedRecords=new ArrayList<String>();

	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		RequestDispatcher rd = null;
		SuperBean bean = new SuperBean();
		String orderid = bean.orderid;
		Common info = new Common();		
		ResultSet rs = null;
		try {
			PreparedStatement pstmt = bean.connection
					.prepareStatement("select * from table_contract where id=?");
			pstmt.setString(1, orderid);
			rs = pstmt.executeQuery();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ArrayList<String> subProName = new ArrayList<String>();
		ArrayList<String> tasks = new ArrayList<String>();
		HashMap<String, String> groupObjidList = new HashMap<String, String>();
		HashMap<String, String> rqstObjidList = new HashMap<String, String>();
		HashMap<String, String> requestTogroup = new HashMap<String, String>();
		try {
			info.getSubprojects(bean, orderid, bean.connection);
			info.getTask(bean, bean.getSubprojectObjid(), bean.connection);
			info.getRequestInstances(bean, bean.connection);
			info.getExternalID(bean, orderid, bean.connection);
			bean.setUpdatedRecords(this.updatedRecords);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		req.setAttribute("bean", bean);
		rd = req.getRequestDispatcher("Home.jsp");
		rd.include(req, res);
	}
	
	public void refresh(SuperBean bean) throws ServletException, IOException{
		this.updatedRecords=bean.getUpdatedRecords();
		HttpServletRequest req=null;
		HttpServletResponse res=null;
		this.doPost(req, res);
	}

}