package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.SuperBean;
import com.Servlet.Common;
import SQL.Sqls;

public class GetSubprojects extends HttpServlet {
	public static String order_id;
	public static Connection con;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd = null;
		String orderid = req.getParameter("orderid");
		String ein = req.getParameter("ein");
		System.out.println("OrderId entered is :" + orderid);
		Common info = new Common();
		SuperBean bean = new SuperBean();
		con = bean.getConnection();
		ResultSet rs = null;
		try {
			PreparedStatement pstmt = con
					.prepareStatement("select * from table_contract where id=?");
			pstmt.setString(1, orderid);
			rs = pstmt.executeQuery();
			int c=0;
			while(rs.next()) c++;	
			if (orderid == null || "null".equalsIgnoreCase(orderid)
					|| c==0) {
				rd = req.getRequestDispatcher("OrderID.jsp");
				PrintWriter out = res.getWriter();
				out.print("<center><i>Order id not found</i></center>");
				rd.include(req, res);
			} else {
				order_id = orderid;
				Connection conn = bean.getConnection();
				bean.setOrderid(orderid);
				System.out.println("After setting orderid");
				info.getSubprojects(bean, orderid, conn);
				info.getTask(bean, bean.getSubprojectObjid(), conn);
				info.getRequestInstances(bean, conn);
				info.getExternalID(bean, orderid, conn);
				req.setAttribute("bean", bean);
				rd = req.getRequestDispatcher("Home.jsp");
				rd.forward(req, res);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void refresh(HttpServletRequest req, HttpServletResponse res,
			SuperBean bean, String orderid, Connection conn)
			throws ServletException, IOException {
		PreparedStatement pstmt = null;
		System.out.println("OrderId in refresh method " + orderid);
		Common info = new Common();
		try {
			info.getSubprojects(bean, orderid, conn);
			info.getTask(bean, bean.getSubprojectObjid(), conn);
			info.getRequestInstances(bean, conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		req.setAttribute("bean", bean);
		RequestDispatcher rd = req.getRequestDispatcher("Refresh.jsp");
		rd.forward(req, res);
	}

}
