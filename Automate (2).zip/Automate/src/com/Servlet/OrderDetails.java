package com.Servlet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.beans.SuperBean;
import SQL.Sqls;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class for Servlet: OrderDetails
 * 
 */
public class OrderDetails extends HttpServlet {

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		String orderID = null;
		SuperBean bean = new SuperBean();
		orderID = bean.getOrderid();
		HashMap<String, String> service = new HashMap<String, String>();
		PreparedStatement pstmt;
		try {
			pstmt = SuperBean.getConnection()
					.prepareStatement(Sqls.ORDER_TITLE);
			pstmt.setString(1, orderID);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println("orderobjid " + rs.getString("orderobjid"));
				bean.setContractObjID(rs.getString("orderobjid"));
				System.out.println("status " + rs.getString("status"));
				bean.setOrderStatus(rs.getString("status"));
				System.out.println("ordertype " + rs.getString("ordertype"));
				bean.setOrderType(rs.getString("ordertype"));
				System.out.println("title " + rs.getString("title"));
				bean.setOrderTitle(rs.getString("title"));
				System.out.println("start_date " + rs.getString("start_date"));
				bean.setOrderDate(rs.getString("start_date"));
			}
			if (bean.getOrderType().equalsIgnoreCase("Modify")) {
				ArrayList<String> provideForModify = new ArrayList<String>();
				pstmt = null;
				rs = null;
				pstmt = SuperBean.getConnection().prepareStatement(
						Sqls.PROVIDE_FOR_MODIFY);
				pstmt.setString(1, orderID);
				rs = pstmt.executeQuery();
				while (rs.next()) {
					System.out.println("Provide order id for modify order "
							+ orderID + " is :" + rs.getString("id"));
					provideForModify.add(rs.getString("id"));
				}
				bean.setProvideForModify(provideForModify);
			}
			pstmt = null;
			rs = null;
			pstmt = SuperBean.getConnection().prepareStatement(
					Sqls.EXTERNAL_ID_AIB);
			pstmt.setString(1, orderID);
			rs = pstmt.executeQuery();
			if (rs.next() && rs != null) {
				bean.setExternalSystem("AIB");
				System.out.println("Extid " + rs.getString("extid"));
				bean.setExternalID(rs.getString("extid"));
			} else {
				pstmt = null;
				rs = null;
				pstmt = SuperBean.getConnection().prepareStatement(
						Sqls.EXTERNAL_ID_DCA);
				pstmt.setString(1, orderID);
				rs = pstmt.executeQuery();
				bean.setExternalSystem("eDCA");
				if (rs.next()) {
					System.out.println("Extid " + rs.getString("extid"));
					bean.setExternalID(rs.getString("extid"));
				}
			}
			pstmt = null;
			rs = null;

			if (bean.getOrderType().equalsIgnoreCase("Modify")) {
				pstmt = SuperBean.getConnection().prepareStatement(
						Sqls.SERVICE_FOR_MODIFY);
			} else {
				pstmt = SuperBean.getConnection().prepareStatement(
						Sqls.SERVICE_FOR_PROVIDE);
			}
			pstmt.setString(1, orderID);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				System.out.println("serviceno " + rs.getString("serviceno")
						+ " status is " + rs.getString("status"));
				service.put(rs.getString("serviceno"), rs.getString("status"));
			}
			bean.setService(service);

			req.setAttribute("bean", bean);
			RequestDispatcher rd = req.getRequestDispatcher("OrderDetails.jsp");
			rd.forward(req, res);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
