package com.Servlet;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.SuperBean;

import SQL.Sqls;

/**
 * Servlet implementation class for Servlet: CommTechRelation
 * 
 */
public class CommTechRelation extends javax.servlet.http.HttpServlet implements
		javax.servlet.Servlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// comm-tech relation
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		SuperBean bean = new SuperBean();
		HashMap<ArrayList, ArrayList> commTechRelation = new HashMap<ArrayList, ArrayList>();
		ArrayList<String> commtechColumnNames = new ArrayList<String>();
		try {
			pstmt = bean.connection.prepareStatement(Sqls.COMM_TECH_RELATION);
			pstmt.setString(1, bean.contractObjID);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			int columnsNumber = rsmd.getColumnCount();
			for (int j = 1; j <= columnsNumber; j++) {
				commtechColumnNames.add(rsmd.getColumnName(j));
			}
			bean.setCommtechColumnNames(commtechColumnNames);
			System.out.println("Comm-Tech Relations");
			while (rs.next()) {
				ArrayList commTech = new ArrayList();
				ArrayList roleService = new ArrayList();
				String tech = rs.getString(1);
				String comm = rs.getString(2);
				String Service = rs.getString(3);
				String role = rs.getString(4);
				PreparedStatement ps = bean.connection
						.prepareStatement(Sqls.TECHNICAL_WITH_OBJID);
				ps.setString(1, tech);
				ResultSet r = ps.executeQuery();
				if (r.next())
					commTech.add(r.getString(1));
				ps.close();
				r.close();
				ps = bean.connection
						.prepareStatement(Sqls.COMMERCIAL_WITH_OBJID);
				ps.setString(1, comm);
				r = ps.executeQuery();
				if (r.next())
					commTech.add(r.getString(1));
				ps.close();
				r.close();
				ps = bean.connection.prepareStatement(Sqls.SERVICE_WITH_OBJID);
				ps.setString(1, Service);
				r = ps.executeQuery();
				if (r.next())
					roleService.add(r.getString(1));
				ps.close();
				r.close();
				roleService.add(role);
				System.out.println(commTech + " : " + roleService);
				commTechRelation.put(commTech, roleService);
			}
			bean.setCommTechRelation(commTechRelation);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		req.setAttribute("bean", bean);
		RequestDispatcher rd = req.getRequestDispatcher("CommTechRelation.jsp");
		rd.forward(req, res);
	}
}