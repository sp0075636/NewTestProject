package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.SuperBean;
import com.conn.GetConnection;

public class DataBaseServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		String env = req.getParameter("env");
		SuperBean bean = new SuperBean();
		int i = Integer.parseInt(env);
		Connection conn = null;
		Common comm = new Common();
		PreparedStatement pstmt = null;
		GetConnection gc = new GetConnection();		
		try {
			conn = gc.getConnection(i);
			if (conn == null) {
				RequestDispatcher rd = req.getRequestDispatcher("index.jsp");
				out
						.println("<center><i>Please Correct Connection details and try!!!</i></center></br>");
				rd.include(req, res);
			} else {
				bean.setI(i);
				bean.setConnection(conn);
				System.out.println("db connection set");
				req.setAttribute("bean", bean);
				env = comm.getEnv(i);
				bean.setEnv(env);
				out.println("<center><i>Connected to " + env
						+ " Environment</i></center></br>");

				RequestDispatcher rd = req.getRequestDispatcher("OrderID.jsp");
				rd.include(req, res);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			out.println("Error in DataBaseServlet connection!!!");
			System.exit(0);
		}

	}

}
