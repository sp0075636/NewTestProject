package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.SuperBean;

import SQL.Sqls;

public class UpdateTasks extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		res.setContentType("text/html");
		GetSubprojects gsp = new GetSubprojects();
		SuperBean bean = new SuperBean();
		PrintWriter out = res.getWriter();
		String taskName = null;
		String reqName = null;
		String groupObjid = null;
		String seqno = null;
		ArrayList<String> updatedRecords = new ArrayList<String>();
		String task = req.getParameter("tasks");
		System.out.println("Task objid recieved : " + task);
		String request = req.getParameter("requests");
		System.out.println("Request objid recieved : " + request);
		String updateProc = "{call UPDATE_SR(?,?,?,?,'0')}";
		
		try {
			CallableStatement cstmt = bean.connection.prepareCall(updateProc);
			PreparedStatement pstmt = bean.connection.prepareStatement(Sqls.TASK_NAME);
			ResultSet rs = null;
			if (task != null && !"null".equalsIgnoreCase(task)) {
				pstmt.setString(1, task);
				rs = pstmt.executeQuery();
				if (rs.next())
					taskName = rs.getString("X_TASK_ID");
				pstmt.close();
				rs.close();
			}
			if (request != null && !"null".equalsIgnoreCase(request)) {
				pstmt = bean.connection.prepareStatement(Sqls.REQUEST_NAME);
				pstmt.setString(1, request);
				rs = pstmt.executeQuery();
				if (rs.next())
					reqName = rs.getString(1);
				pstmt.close();
				rs.close();
				pstmt = bean.connection.prepareStatement(Sqls.SEQ_NO);
				pstmt.setString(1, request);
				rs = pstmt.executeQuery();
				if (rs.next()) {
					groupObjid = rs.getString(1);
					seqno = rs.getString(2);
				}
				pstmt.close();
				rs.close();
			}
			int i = 0;
			if (request != null && !"null".equalsIgnoreCase(request)
					&& groupObjid != null && seqno != null && reqName != null) {
				if (SuperBean.getI() > 10) {
					cstmt.setString(1, "TABLE_GROUP_INST");
					cstmt.setString(2, "SEQNO");
					cstmt.setString(3, seqno);
					cstmt.setString(4, groupObjid);
					i = cstmt.executeUpdate();
					cstmt.close();					
					if (i == 1) {
						System.out.println("UPDATED GROUP OBJID : "
								+ groupObjid + " WITH SEQQ NO : " + seqno);
					}
					cstmt = bean.connection.prepareCall(updateProc);
					cstmt = bean.connection.prepareCall(updateProc);
					cstmt.setString(1, "TABLE_RQST_INST");
					cstmt.setString(2, "STATUS");
					cstmt.setString(3, "COMPLETE");
					cstmt.setString(4, request);
					i = cstmt.executeUpdate();
					cstmt.close();
					
					if (i == 1) {
						System.out.println("UPDATED REQUEST OBJID : " + request
								+ " WITH NAME : " + reqName);
					}
					updatedRecords.add("UPDATED GROUP OBJID : " + groupObjid
							+ " WITH SEQ NO : " + seqno);
					out.print("UPDATED GROUP OBJID : " + groupObjid
							+ " WITH SEQ NO : " + seqno);
					updatedRecords.add("UPDATED REQUEST OBJID : " + request
							+ " WITH NAME : " + reqName);
					out.print("UPDATED REQUEST OBJID : " + request
							+ " WITH NAME : " + reqName);

				} else {
					pstmt = bean.connection.prepareStatement(Sqls.UPDATE_SEQ_NO);
					pstmt.setString(1, seqno);
					pstmt.setString(2, groupObjid);
					i = pstmt.executeUpdate();
					if (i == 1) {
						System.out.println("UPDATED GROUP OBJID : "
								+ groupObjid + " WITH SEQQ NO : " + seqno);
					}
					pstmt.close();
					pstmt = bean.connection.prepareStatement(Sqls.UPDATE_REQUEST);
					pstmt.setString(1, request);
					i = pstmt.executeUpdate();
					if (i == 1) {
						System.out.println("UPDATED REQUEST OBJID : " + request
								+ " WITH NAME : " + reqName);
					}
					pstmt.close();
					updatedRecords.add("UPDATED GROUP OBJID : " + groupObjid
							+ " WITH SEQ NO : " + seqno);
					out.print("UPDATED GROUP OBJID : " + groupObjid
							+ " WITH SEQ NO : " + seqno);
					updatedRecords.add("UPDATED REQUEST OBJID : " + request
							+ " WITH NAME : " + reqName);
					out.print("UPDATED REQUEST OBJID : " + request
							+ " WITH NAME : " + reqName);
				}
			}
			if (task != null && !"null".equalsIgnoreCase(task)
					&& taskName != null) {
				if (taskName.contains("CPE base config")) {
					int u = 0;
					int p = 0;
					pstmt = bean.connection.prepareStatement(Sqls.INTERACTIONS);
					pstmt.setString(1, task);
					rs = pstmt.executeQuery();
					if (rs != null && rs.next()) {
						String objid = rs.getString("objid");
						if (SuperBean.getI() > 10) {
							cstmt = bean.connection.prepareCall(updateProc);
							cstmt.setString(1, "table_x_gen_trans");
							cstmt.setString(2, "x_status");
							cstmt.setString(3, "Sent");
							cstmt.setString(4, objid);
							u = cstmt.executeUpdate();
							cstmt.close();	
							cstmt = bean.connection.prepareCall(updateProc);
							cstmt.setString(1, "table_x_gen_trans");
							cstmt.setString(2, "x_resp_status");
							cstmt.setString(3, "Plan Complete");
							cstmt.setString(4, objid);
							p = cstmt.executeUpdate();
							cstmt.close();	
						} else {
							pstmt.close();
							pstmt = bean.connection
									.prepareStatement(Sqls.UPDATE_BASE_CONFIG_INTERACTIONS);
							pstmt.setString(1, objid);
							u = pstmt.executeUpdate();
						}
						if (u == 1 && (p == 1 || SuperBean.getI() <= 10)) {
							updatedRecords
									.add("UPDATED INTERACTIONS FOR BASE CONFIG TASK OBJID :"
											+ task + " WITH NAME : " + taskName);
							out.print("UPDATED INTERACTIONS FOR BASE CONFIG TASK OBJID :"
									+ task + " WITH NAME : " + taskName);
						}
					}

				}
				if (SuperBean.getI() > 10) {
					cstmt = bean.connection.prepareCall(updateProc);
					cstmt.setString(1, "TABLE_X_I_WP_TASK");
					cstmt.setString(2, "X_STATUS");
					cstmt.setString(3, "Ended");
					cstmt.setString(4, task);
					i = cstmt.executeUpdate();
					cstmt.close();	
					if (i == 1) {
						System.out.println("UPDATED TASK OBJID :" + task
								+ " WITH NAME : " + taskName);
						pstmt.close();
					}
					updatedRecords.add("UPDATED TASK OBJID :" + task
							+ " WITH NAME : " + taskName);
					out.print("UPDATED TASK OBJID :" + task
							+ " WITH NAME : " + taskName);
				} else {
					pstmt = bean.connection.prepareStatement(Sqls.UPDATE_TASK);
					pstmt.setString(1, task);
					i = pstmt.executeUpdate();
					if (i == 1) {
						System.out.println("UPDATED TASK OBJID :" + task
								+ " WITH NAME : " + taskName);
						pstmt.close();
					}
					updatedRecords.add("UPDATED TASK OBJID :" + task
							+ " WITH NAME : " + taskName);
					out.print("UPDATED TASK OBJID :" + task
							+ " WITH NAME : " + taskName);

				}
			}

			bean.setUpdatedRecords(updatedRecords);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				bean.connection.commit();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		Home home = new Home();
		home.doPost(req, res);
	}
}
