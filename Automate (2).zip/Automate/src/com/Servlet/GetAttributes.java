package com.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beans.SuperBean;
import SQL.Sqls;

/**
 * Servlet implementation class for Servlet: GetAttributes
 * 
 */
public class GetAttributes extends javax.servlet.http.HttpServlet implements
		javax.servlet.Servlet {

	protected void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		String Attribute = req.getParameter("attribute");
		RequestDispatcher rd = null;
		SuperBean beans = new SuperBean();
		try {
			
			HashMap<String, String> objidToAttribute = new HashMap<String, String>();
			 PreparedStatement pstmt = beans.connection.prepareStatement(Sqls.ATTRIBUTE_INFO);
				pstmt.setString(1, Attribute);
				pstmt.setString(2, beans.orderid);
				ResultSet rs = pstmt.executeQuery();
				String service = null;

				while (rs.next()) {
					String attribute = rs.getString("ATTRIB_NAME") + "[Set : "
							+ rs.getString("ATTRIBUTE_SET") + "][value : "
							+ rs.getString("ATTRIB_VALUE") + "]";
					objidToAttribute.put(rs.getString("INST_OBJID"), attribute);					
				}
			beans.setObjidToAttribute(objidToAttribute);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		req.setAttribute("bean", beans);
		rd = req.getRequestDispatcher("UpdateAttribute.jsp");
		rd.forward(req, res);

	}

}
